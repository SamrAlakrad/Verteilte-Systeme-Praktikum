package BambooKeys.model;

import lombok.Data;
import org.springframework.data.annotation.Id;

import javax.validation.constraints.NotBlank;
import java.time.LocalDate;

@Data
public class Order {
    @Id
    private String id;
    private String url;
    @NotBlank
    private  String productId;
    private LocalDate date;
    @NotBlank
    private String payment;
    private float total;

    public Order(String id, String url, String productId, LocalDate date, String payment, float total) {
        this.id = id;
        this.url = url;
        this.productId = productId;
        this.date = date;
        this.payment = payment;
        this.total = total;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }
}
