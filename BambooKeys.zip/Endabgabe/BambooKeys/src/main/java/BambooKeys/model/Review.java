package BambooKeys.model;

import lombok.Data;
import org.springframework.data.annotation.Id;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

@Data
public class Review {
    @Id
    private String id;
    private String url;
    private String publisher;
    public static int [] RATE= {'1', '2', '3', '4', '5'};

    private int starRating;
    private String reviewText;


    public Review() {
    }

    public Review(String id, String url, String publisher, int starRating, String reviewText) {
        this.id = id;
        this.url = url;
        this.publisher = publisher;
        this.starRating = starRating;
        this.reviewText = reviewText;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public static int[] getRATE() {
        return RATE;
    }

    public static void setRATE(int[] RATE) {
        Review.RATE = RATE;
    }

    public int getStarRating() {
        return starRating;
    }

    public void setStarRating(int starRating) {
        this.starRating = starRating;
    }

    public String getReviewText() {
        return reviewText;
    }

    public void setReviewText(String reviewText) {
        this.reviewText = reviewText;
    }
}
