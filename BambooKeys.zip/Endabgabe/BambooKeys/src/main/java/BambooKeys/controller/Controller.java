package BambooKeys.controller;

import BambooKeys.model.*;
import BambooKeys.service.CustomerService;
import BambooKeys.service.ProductService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@RestController
@AllArgsConstructor
public class Controller {

    private  final CustomerService customerService;
    private  final ProductService productService;

    @PostMapping("/Customers")
    public ResponseEntity<Customer> createCustomer(@Valid @RequestBody Customer customer, HttpServletRequest request) {
        Customer createdCustomer = customerService.createCustomer(customer, request);
        return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
    }

    @GetMapping("/Customers/{id}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable String id, HttpServletRequest request) {
        Customer customer = customerService.getCustomerById(id, request);
        return new ResponseEntity<>(customer, HttpStatus.OK);
    }

    @GetMapping("/Customers")
    public ResponseEntity<List<Customer>> getCustomers(HttpServletRequest request) {
        List<Customer> customers = customerService.getCustomers(request);
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

    @PutMapping("/Customers/{id}")
    public ResponseEntity<Customer> updateCustomerById(@PathVariable String id, @Valid @RequestBody Customer customerToUpdate, HttpServletRequest request) {
        Customer customer = customerService.updateCustomerById(id, customerToUpdate, request);
        return new ResponseEntity<>(customer, HttpStatus.ACCEPTED);
    }

    @PutMapping("/Customers")
    public ResponseEntity<Customer> updateAllCustomers(@Valid @RequestBody Customer customerToUpdate, HttpServletRequest request) {
        Customer customer = customerService.updateAllCustomers(customerToUpdate, request);
        return new ResponseEntity<>(customer, HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/Customers/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable String id) {
        customerService.deleteCustomer(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/Customers")
    public ResponseEntity<List<Customer>> deleteAllCustomers() {
        List<Customer> customers = customerService.deleteAllCustomers();
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }
    //*********************************************************************************************

    @PostMapping("/Products")
    public ResponseEntity<Product> addNewProduct(@Valid @RequestBody Product product, HttpServletRequest request) {
        Product createdProduct = productService.addNewProduct(product, request);
        return new ResponseEntity<>(createdProduct, HttpStatus.CREATED);
    }

    @GetMapping("/Products")
    public ResponseEntity<List<Product>> getProducts(HttpServletRequest request) {
        List<Product> products = productService.getProducts(request);
        return new ResponseEntity(products, HttpStatus.OK);
    }

    @GetMapping("/Products/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable String id,  HttpServletRequest request) {
        Product product = productService.getProductById(id, request);
        return new ResponseEntity(product, HttpStatus.OK);
    }

    @PutMapping("/Products")
    public ResponseEntity<Product> updateAllProducts(@Valid @RequestBody Product productToUpdate, HttpServletRequest request) {
        Product product = productService.updateAllProducts(productToUpdate, request);
        return new ResponseEntity<>(product, HttpStatus.ACCEPTED);
    }

    @PutMapping("/Products/{id}")
    public ResponseEntity<Product> updateProductById(@PathVariable String id, @Valid @RequestBody Product productToUpdate, HttpServletRequest request) {
        Product product = productService.updateProductById(id, productToUpdate, request);
        return new ResponseEntity<>(product, HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/Products")
    public ResponseEntity<List<Product>> deleteAllProducts() {
        List<Product> products = productService.deleteAllProducts();
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @DeleteMapping("/Products/{id}")
    public ResponseEntity<Product> deleteProduct(@PathVariable String id) {
        productService.deleteProduct(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    //...................................................................................

    @PostMapping("Questions")
    public ResponseEntity<Question> addNewQuestions(@Valid @RequestBody Question question, HttpServletRequest request) {
        Question createdQuestion = customerService.addNewQuestion(question, request);
        return new ResponseEntity<>(createdQuestion, HttpStatus.CREATED);

    }

    @GetMapping("Questions")
    public ResponseEntity<List<Question>> getQuestions(HttpServletRequest request) {
        List<Question> questions = customerService.getQuestions(request);
        return new ResponseEntity(questions, HttpStatus.OK);
    }

    @GetMapping("/Questions/{id}")
    public ResponseEntity<Question> getQuestionById(@PathVariable String id, HttpServletRequest request) {
        Question question =  customerService.getQuestionById(id, request);
        return new ResponseEntity(question, HttpStatus.OK);
    }
    @PutMapping("/Questions")
    public ResponseEntity<Question> updateAllQuestions(@Valid @RequestBody Question questionToUpdate, HttpServletRequest request) {
        Question question = customerService.updateAllQuestion(questionToUpdate, request);
        return new ResponseEntity<>(question, HttpStatus.ACCEPTED);
    }

    @PutMapping("/Questions/{id}")
    public ResponseEntity<Question> updateQuestionById(@PathVariable String id, @Valid @RequestBody Question questionToUpdate, HttpServletRequest request) {
        Question question = customerService.updateQuestionById(id, questionToUpdate, request);
        return new ResponseEntity<>(question, HttpStatus.ACCEPTED);
    }

    @DeleteMapping("Questions")
    public ResponseEntity<List<Question>> deleteAllQuestions() {
        List<Question> questions = customerService.deleteAllQuestions();
        return new ResponseEntity<>(questions, HttpStatus.OK);
    }

    @DeleteMapping("Questions/{id}")
    public ResponseEntity<Question> deleteQuestion(@PathVariable String id) {
        customerService.deleteQuestion(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //****************************************************************************************************

    @PostMapping("Reviews")
    public ResponseEntity<Review> addNewReview(@Valid @RequestBody Review review, HttpServletRequest request) {
        Review createdReview = customerService.addNewReview(review, request);
        return new ResponseEntity<>(createdReview, HttpStatus.CREATED);
    }

    @GetMapping("/Reviews")
    public ResponseEntity<List<Review>> getReviews(HttpServletRequest request) {
        List<Review> reviews = customerService.getReviews(request);
        return new ResponseEntity(reviews, HttpStatus.OK);
    }

    @GetMapping("/Reviews/{id}")
    public ResponseEntity<Review> getReviewById(@PathVariable String id, HttpServletRequest request) {
        Review review = customerService.getReviewById(id, request);
        return new ResponseEntity(review, HttpStatus.OK);
    }

    @PutMapping("/Reviews")
    public ResponseEntity<Review> updateAllReviews(@Valid @RequestBody Review reviewToUpdate, HttpServletRequest request) {
        Review review = customerService.updateAllReviews(reviewToUpdate, request);
        return new ResponseEntity<>(review, HttpStatus.ACCEPTED);
    }

    @PutMapping("/Reviews/{id}")
    public ResponseEntity<Review> updateReviewById(@PathVariable String id, @Valid @RequestBody Review reviewToUpdate, HttpServletRequest request) {
        Review review = customerService.updateReviewById(id, reviewToUpdate, request);
        return new ResponseEntity<>(review, HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/Reviews")
    public ResponseEntity<List<Review>> deleteAllReviews() {
        List<Review> reviews = customerService.deleteAllReviews();
        return new ResponseEntity<>(reviews, HttpStatus.OK);
    }

    @DeleteMapping("/Reviews/{id}")
    public ResponseEntity<Review> deleteReview(@PathVariable String id) {
        customerService.deleteReview(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //*******************************************************************************************

    @PostMapping("/Orders")
    public ResponseEntity<Order> addNewOrder(@Valid @RequestBody Order order, HttpServletRequest request) {
        Order createdOrder = productService.addNewOrder(order, request);
        return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);
    }

    @GetMapping("/Orders")
    public ResponseEntity<List<Order>> getOrders(HttpServletRequest request) {
        List<Order> orders = productService.getOrders(request);
        return new ResponseEntity(orders, HttpStatus.OK);
    }

    @GetMapping("/Orders/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable String id, HttpServletRequest request) {
        Order order = productService.getOrderById(id, request);
        return new ResponseEntity(order, HttpStatus.OK);
    }

    @PutMapping("/Orders")
    public ResponseEntity<Order> updateAllOrders(@Valid @RequestBody Order orderToUpdate, HttpServletRequest request) {
        Order order = productService.updateAllOrders(orderToUpdate, request);
        return new ResponseEntity<>(order, HttpStatus.ACCEPTED);
    }

    @PutMapping("/Orders/{id}")
    public ResponseEntity<Order> updateOrderById(@PathVariable String id, @Valid @RequestBody Order orderToUpdate,  HttpServletRequest request) {
        Order order = productService.updateOrderById(id, orderToUpdate, request);
        return new ResponseEntity<>(order, HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/Orders")
    public ResponseEntity<List<Order>> deleteAllOrders() {
        List<Order> orders = productService.deleteAllOrders();
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    @DeleteMapping("/Orders/{id}")
    public ResponseEntity<Order> deleteOrder(@PathVariable String id) {
        productService.deleteOrder(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
