package BambooKeys.repository;

import BambooKeys.model.Order;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface OrderRepository  extends MongoRepository<Order, String> {
    Optional<Order> findOrderByProductId(String productId);
}
