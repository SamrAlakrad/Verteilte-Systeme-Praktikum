package BambooKeys.repository;

import BambooKeys.model.Question;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface QuestionRepository extends MongoRepository<Question, String> {

    Optional<Question> findByEmail(String email);

    Optional<Question> findByProductId(String productId);
}
