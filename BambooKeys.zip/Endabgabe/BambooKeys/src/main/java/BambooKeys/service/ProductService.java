package BambooKeys.service;

import BambooKeys.model.Order;
import BambooKeys.exception.EntityAlreadyExistsException;
import BambooKeys.exception.EntityNotFoundException;
import BambooKeys.model.Product;
import BambooKeys.repository.OrderRepository;
import BambooKeys.repository.ProductRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class ProductService {
    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;


    // Product name and brand can not be duplicated
    public Product addNewProduct(Product product,  HttpServletRequest request) {
        checkExistingProduct(product);
        product.setId(String.valueOf(productRepository.count()+1));
        product.setUrl(String.valueOf(request.getRequestURL()));
        productRepository.save(product);
        return product;
    }
    private void checkExistingProduct(Product product) {
        productRepository.findByNameAndBrand(product.getName(), product.getBrand())
                .ifPresent(cus -> {
                    throw new EntityAlreadyExistsException(String.format("Product with the name: %s and the brand: %s is already existing",product.getName(), product.getBrand()));});
    }

    public List<Product> getProducts(HttpServletRequest request) {
        for (Product product: productRepository.findAll()){
            product.setUrl(String.valueOf(request.getRequestURL()));
            productRepository.save(product);
        }
        return productRepository.findAll();
    }

    public Product getProductById(String id, HttpServletRequest request) {
        Product product= productRepository.findById(id)
                    .orElseThrow(() -> new EntityNotFoundException(String.format(
                            "Product not found with id: %s", id)));
        product.setUrl(String.valueOf(request.getRequestURL()));
        return product;
    }
    public Product findProductById(String id) {
        Product product= productRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(String.format(
                        "Product not found with id: %s", id)));
        return product;
    }

    public List<Product> deleteAllProducts() {
        productRepository.deleteAll();
        return productRepository.findAll();
    }

    public void deleteProduct(String id) {
       Optional <Product> product= productRepository.findById(id);
        if(product.isPresent()){
            productRepository.deleteById(id);
        }else{
           throw new EntityNotFoundException(String.format("Product not found with id: %s", id));
        }
    }

    // Product's name and brand can not be changed
    public Product updateAllProducts(Product productToUpdate, HttpServletRequest request) {
        if ((productRepository.count() !=0)) {
            Optional<Product> product = productRepository.findByNameAndBrand(productToUpdate.getName(), productToUpdate.getBrand());
            if (product.isPresent()) {
                productToUpdate.setId(product.get().getId());
                for (Product i : productRepository.findAll()) {
                    if (i.getId().equals(productToUpdate.getId())) {
                        i.setUrl(String.valueOf(request.getRequestURL()));
                        i.setOldPrice(i.getNewPrice());
                        i.setNewPrice(productToUpdate.getNewPrice());
                        productRepository.save(i);
                    }
                }
            }else{
                throw new EntityNotFoundException(String.format("Product with the name: %s and the brand: %s is not existing",productToUpdate.getName(), productToUpdate.getBrand()));
            }
        }else {
            throw new EntityNotFoundException(String.format("Product with the name: %s and the brand: %s is not existing",productToUpdate.getName(), productToUpdate.getBrand()));
        }
        return productToUpdate;
    }

    // Product's name and brand can be changed
    public Product updateProductById(String id, Product productToUpdate, HttpServletRequest request) {
        if ((productRepository.count() !=0)) {
            Optional<Product> product = productRepository.findById(id);
            if (product.isPresent()) {
                productToUpdate.setId(product.get().getId());
                for (Product i : productRepository.findAll()) {
                    if (i.getId().equals(productToUpdate.getId())) {
                        i.setUrl(String.valueOf(request.getRequestURL()));
                        i.setName(productToUpdate.getName());
                        i.setBrand(productToUpdate.getBrand());
                        i.setOldPrice(i.getNewPrice());
                        i.setNewPrice(productToUpdate.getNewPrice());
                        productRepository.save(i);
                    }
                }
            }else{
                throw  new EntityNotFoundException(String.format("Product not found with id: %s", id));
            }
        }else {
            throw  new EntityNotFoundException(String.format("Product not found with id: %s", id));
        }
        return productToUpdate;
    }
//*************************************************************************************************++++

    // There must be a product in order to create an order
    public Order addNewOrder(Order orderToAdd, HttpServletRequest request) {
        if(productRepository.count() !=0){
           Optional<Product> product= productRepository.findById(orderToAdd.getProductId());
           if(product.isPresent()){
               checkExistingOrderByProductId(orderToAdd.getProductId());
               checkPayment(orderToAdd.getPayment());
               orderToAdd.setUrl(String.valueOf(request.getRequestURL()));
               orderToAdd.setId(generateOrderId());
               orderToAdd.setDate(LocalDate.now());
               orderToAdd.setTotal(product.get().getNewPrice());
               orderRepository.save(orderToAdd);
               return orderToAdd;
           }else {
               throw new EntityNotFoundException(String.format("There is no product with id: " + orderToAdd.getProductId()));
           }
        }else {
            throw new EntityNotFoundException(String.format("There is no product with id: " + orderToAdd.getProductId()));
        }
    }

    private String generateOrderId() {
        if(orderRepository.count()==0){
            return "0001";
        }else if(orderRepository.count()>=1 &&orderRepository.count()<10){
            return "000"+(orderRepository.count()+1);
        }else if(orderRepository.count()<100 && orderRepository.count()>=10){
            return "00"+(orderRepository.count()+1);
        }else if(orderRepository.count()<1000 && orderRepository.count()>=100){
            return "0"+(orderRepository.count()+1);
        }else{
            return ""+(orderRepository.count()+1);
        }
    }

    private void checkPayment(String payment) {
        switch (payment) {
            case "Debit":  payment = "Debit";
                break;
            case "Bill":  payment= "Bill";
                break;
            case "Credit Card":  payment = "Credit Card";
                break;
            case "EC-Card":  payment = "EC-Card";
                break;
            default: throw new EntityNotFoundException("You have to give one of the following payments: Debit, Bill, Credit Card, EC-Card");
        }
    }
    private void checkExistingOrderByProductId(String productId) {
        orderRepository.findOrderByProductId(productId)
                .ifPresent(cus -> {
                    throw new EntityAlreadyExistsException(String.format("There is already an order for the product with id: %s ",productId));
                });
    }

    public List<Order> getOrders(HttpServletRequest request) {
       for(Order order: orderRepository.findAll()){
           order.setUrl(String.valueOf(request.getRequestURL()));
           orderRepository.save(order);
       }
        return orderRepository.findAll();
    }

    // It will return just one order " id!= productId"
    public Order getOrderById(String id, HttpServletRequest request) {
        Order order= orderRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(String.format(
                        "Order not found with id: %s", id)));
        order.setUrl(String.valueOf(request.getRequestURL()));
        return order;
    }

    public List<Order> deleteAllOrders() {
        orderRepository.deleteAll();
        return orderRepository.findAll();
    }

    public void deleteOrder(String id) {
        Optional<Order> order= orderRepository.findById(id);
        if(order.isPresent()){
            orderRepository.deleteById(id);
        }else{
          throw  new EntityNotFoundException(String.format("Order not found with id: %s", id));
        }
    }

    public Order updateAllOrders(Order orderToUpdate, HttpServletRequest request) {
        if(orderRepository.findAll().size()!=0) {
            Optional<Product> product= productRepository.findById(orderToUpdate.getProductId());
           if(product.isPresent()){
               checkPayment(orderToUpdate.getPayment());
               for (Order i : orderRepository.findAll()) {
                   if (i.getProductId().equals(orderToUpdate.getProductId())) {
                       i.setUrl(String.valueOf(request.getRequestURL()));
                       i.setPayment(orderToUpdate.getPayment());
                       orderRepository.save(i);
                   }
               }
             return orderToUpdate;
           }else {
               throw new EntityNotFoundException(String.format("Product not found with the id: %s",orderToUpdate.getProductId() ));
           }
            }else{
                throw new EntityNotFoundException(String.format("Order not found!"));
            }
    }
    private void checkExistingOrder(String id) {
        orderRepository.findAll().stream()
                .filter(order -> order.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new EntityNotFoundException(String.format("Order not found with id: " + id)));
    }

    private void updateOrder(String id, Order orderToUpdate, HttpServletRequest request) {
        for(Order order: orderRepository.findAll()){
            if(order.getId().equals(id)){
                order.setUrl(String.valueOf(request.getRequestURL()));
                order.setPayment(orderToUpdate.getPayment());
                orderRepository.save(order);
            }
        }
    }

    public Order updateOrderById(String id, Order orderToUpdate, HttpServletRequest request) {
         if(orderRepository.findAll().size()!=0) {
             Optional<Product> product= productRepository.findById(orderToUpdate.getProductId());
             if(product.isPresent()){
                checkExistingOrder(id);
                checkPayment(orderToUpdate.getPayment());
                updateOrder(id, orderToUpdate, request);
                return orderToUpdate;
            }else {
                 throw new EntityNotFoundException(String.format("Product not found with id: " + orderToUpdate.getProductId()));
             }
            }else{
                throw new EntityNotFoundException(String.format("Order not found with id: " + id));
            }

    }
}
