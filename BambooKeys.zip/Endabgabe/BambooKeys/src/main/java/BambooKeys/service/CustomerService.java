package BambooKeys.service;

import BambooKeys.model.Customer;
import BambooKeys.model.Review;
import BambooKeys.repository.ReviewRepository;
import BambooKeys.exception.EntityAlreadyExistsException;
import BambooKeys.exception.EntityNotFoundException;
import BambooKeys.model.Product;
import BambooKeys.model.Question;
import BambooKeys.repository.CustomerRepository;
import BambooKeys.repository.QuestionRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class CustomerService {
    private final CustomerRepository customerRepository;
    private final QuestionRepository questionRepository;
    private final ReviewRepository reviewRepository;
    private final ProductService productService;

    private static final String ALREADY_EXISTS_MESSAGE = "Customer with the E-mail: %s is already existing";


    // Email is unique
    public Customer createCustomer(Customer customer, HttpServletRequest request) {
        checkExistingCustomer(customer);
        customer.setId(String.valueOf(customerRepository.count()+1));
        customer.setUrl(String.valueOf(request.getRequestURL()));
        customerRepository.save(customer);
        return customer;
    }

    private void checkExistingCustomer(Customer customer) {
     customerRepository.findByEmail(customer.getEmail())
                .ifPresent(cus -> {
                    throw new EntityAlreadyExistsException(String.format(ALREADY_EXISTS_MESSAGE, customer.getEmail()));
                });
    }

    public List<Customer> getCustomers(HttpServletRequest request) {

         for(Customer customer: customerRepository.findAll()){
             customer.setUrl(String.valueOf(request.getRequestURL()));
             customerRepository.save(customer);
         }
         return customerRepository.findAll();
    }

    public Customer getCustomerById(String id, HttpServletRequest request) {
         Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(String.format("Customer not found with id: %s", id)));
        customer.setUrl(String.valueOf(request.getRequestURL()));
        return customer;
    }

    public void deleteCustomer(String id) {
        Optional<Customer> customer= customerRepository.findById(id);
        if(customer.isPresent()){
            customerRepository.deleteById(id);
        }else{
            throw new EntityNotFoundException(String.format("Customer not found with id: %s", id));
        }
    }

    public List<Customer> deleteAllCustomers() {
        customerRepository.deleteAll();
        return customerRepository.findAll();
    }

    // Customer can not change his E-mail
    public Customer updateCustomerById(String id, Customer customerToUpdate, HttpServletRequest request) {
     if(customerRepository.count()!=0){
         Optional<Customer> customer= customerRepository.findById(id);
         if(customer.isPresent()){
             customerToUpdate.setId(id);
             for(Customer i: customerRepository.findAll()){
                 if(i.getId().equals(customerToUpdate.getId())&&
                 i.getEmail().equalsIgnoreCase(customerToUpdate.getEmail())){
                     i.setUrl(String.valueOf(request.getRequestURL()));
                     i.setFirstname(customerToUpdate.getFirstname());
                     i.setLastname(customerToUpdate.getLastname());
                     i.setAddress(customerToUpdate.getAddress());
                     i.setPassword(customerToUpdate.getPassword());
                     customerRepository.save(i);
                     return  customerToUpdate;
                 }
             }
         } throw  new EntityNotFoundException(String.format("Customer with id: %s is not existing", id));
     }
        throw  new EntityNotFoundException(String.format("Customer with id: %s is not existing", id));
    }

    // Customer can change his firstname, lastname, address and his password
    // Wrong email means _> Customer not found
    public Customer updateAllCustomers(Customer customerToUpdate, HttpServletRequest request) {
        if(customerRepository.count()!=0){
            Optional<Customer> customer= customerRepository.findByEmail(customerToUpdate.getEmail());
            if(customer.isPresent()){
                customerToUpdate.setId(customer.get().getId());
                for(Customer i: customerRepository.findAll()){
                    if(i.getId().equals(customerToUpdate.getId())&&
                            i.getEmail().equalsIgnoreCase(customerToUpdate.getEmail())){
                        i.setUrl(String.valueOf(request.getRequestURL()));
                        i.setFirstname(customerToUpdate.getFirstname());
                        i.setLastname(customerToUpdate.getLastname());
                        i.setAddress(customerToUpdate.getAddress());
                        i.setPassword(customerToUpdate.getPassword());
                        customerRepository.save(i);
                        return  customerToUpdate;
                    }
                }
                throw new EntityNotFoundException(String.format("Customer with E-mail: %s is not existing", customerToUpdate.getEmail()));
            }
        }
        throw new EntityNotFoundException(String.format("Customer with the E-mail: %s is not existing", customerToUpdate.getEmail()));

    }

    //..................................................................................................

    // firstname, lastname and email must be correct
    // A customer can add just one question for each product
    public Question addNewQuestion(Question questionToAdd, HttpServletRequest request) {
       Optional<Customer> customer =customerRepository.findByFirstnameAndLastnameAndEmail(
               questionToAdd.getFirstname(), questionToAdd.getLastname(),questionToAdd.getEmail());
        if(customer.isPresent()){
           Product product= productService.findProductById(questionToAdd.getProductId());
           if(product!=null){
               checkExistingQuestion(questionToAdd);
               questionToAdd.setId(String.valueOf(questionRepository.count()+1));
               questionToAdd.setUrl(String.valueOf(request.getRequestURL()));
               questionRepository.save(questionToAdd);
               return questionToAdd;
           }else {
               throw new EntityNotFoundException(String.format("Product not found for the id: %s", questionToAdd.getProductId()));
           }
        }
        throw new EntityNotFoundException(String.format("Firstname, lastname or email is not correct!"));
    }

    private void checkExistingQuestion(Question question) {
        questionRepository.findByProductId(question.getProductId())
                .ifPresent(cus -> {
                    throw new EntityAlreadyExistsException(String.format("Question for the product with the id: %s is already existing", question.getProductId()));
                });
    }

    public List<Question> getQuestions(HttpServletRequest request) {
        for (Question question: questionRepository.findAll()){
            question.setUrl(String.valueOf(request.getRequestURL()));
            questionRepository.save(question);
        }
        return questionRepository.findAll();
    }


    public Question getQuestionById(String id, HttpServletRequest request) {
        Question question= questionRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(String.format("Question not found with id: %s", id)));
        question.setUrl(String.valueOf(request.getRequestURL()));
        return question;
    }

    public List<Question> deleteAllQuestions() {
        questionRepository.deleteAll();
        return questionRepository.findAll();
    }

    public void deleteQuestion(String id) {
        Optional<Question> question= questionRepository.findById(id);
        if(question.isPresent()){
            questionRepository.deleteById(id);
        }else{
          throw  new EntityNotFoundException(String.format("Question not found with id: %s", id));
        }
    }

    // Just category, subject and description can be changed
    public Question updateAllQuestion(Question questionToUpdate,HttpServletRequest request ) {
        if (customerRepository.findAll().size() != 0 || questionRepository.findAll().size() != 0){
            Optional<Customer> customer =customerRepository.findByFirstnameAndLastnameAndEmail(
                    questionToUpdate.getFirstname(), questionToUpdate.getLastname(),questionToUpdate.getEmail());
            if (customer.isPresent()) {

             Optional<Question> question= questionRepository.findByProductId(questionToUpdate.getProductId());
                if(question.isPresent()){
                    for (Question i : questionRepository.findAll()) {
                        if (i.getProductId().equals(questionToUpdate.getProductId())) {
                            i.setUrl(String.valueOf(request.getRequestURL()));
                            i.setCategory(questionToUpdate.getCategory());
                            i.setSubject(questionToUpdate.getSubject());
                            i.setDescription(questionToUpdate.getDescription());
                            questionRepository.save(i);
                            return questionToUpdate;
                        }
                    }
                }else{
                    throw new EntityNotFoundException(String.format("Product not found with the id: %s",questionToUpdate.getProductId()));
                }
            }
            else {
                throw new EntityNotFoundException(String.format("Customer not found!, Please write your email, firstname and your lastname correctly!"));
            }
            }else{
            throw new EntityNotFoundException(String.format("Question not found!"));
        }
        return questionToUpdate;
    }

    // Just category, subject and description can be changed
    public Question updateQuestionById(String id, Question questionToUpdate, HttpServletRequest request) {
       Optional<Question> que= questionRepository.findById(id);
       if(que.isPresent()){
           if (customerRepository.findAll().size() != 0 || questionRepository.findAll().size() != 0){
               Optional<Customer> customer =customerRepository.findByFirstnameAndLastnameAndEmail(
                       questionToUpdate.getFirstname(), questionToUpdate.getLastname(),questionToUpdate.getEmail());
               if (customer.isPresent()) {

                   Optional<Question> question= questionRepository.findByProductId(questionToUpdate.getProductId());
                   if(question.isPresent()){
                       for (Question i : questionRepository.findAll()) {
                           if (i.getProductId().equals(questionToUpdate.getProductId())) {
                               i.setUrl(String.valueOf(request.getRequestURL()));
                               i.setCategory(questionToUpdate.getCategory());
                               i.setSubject(questionToUpdate.getSubject());
                               i.setDescription(questionToUpdate.getDescription());
                               questionRepository.save(i);
                               return questionToUpdate;
                           }
                       }
                   }else{
                       throw new EntityNotFoundException(String.format("Product not found with the id: %s",questionToUpdate.getProductId()));
                   }
               }
               else {
                   throw new EntityNotFoundException(String.format("Customer not found!, Please write your email, firstname and your lastname correctly!"));
               }
           }else{
               throw new EntityNotFoundException(String.format("Question not found!"));
           }
           return questionToUpdate;

       }else{
           throw new EntityNotFoundException(String.format("Question not found with the id: %s", id));
       }
    }
//............................................................................................................

    // The reviewer does not have to be a customer, but can only leave a review "just one: Name is unique"
    public Review addNewReview(Review reviewToAdd, HttpServletRequest request) {
        Review review = new Review();

            checkExistingPublisher(reviewToAdd.getPublisher());
            for(int i=0; i<=Review.RATE.length;i++){
                if(i==reviewToAdd.getStarRating()){
                    review.setUrl(String.valueOf(request.getRequestURL()));
                    review.setPublisher(reviewToAdd.getPublisher());
                    review.setStarRating(i);
                    review.setReviewText(review.getReviewText());
                    review.setId(String.valueOf(reviewRepository.count()+1));
                   reviewRepository.save(review);
                    return review;
                }
            }
            throw  new EntityAlreadyExistsException(String.format("please give a rating from 1 to 5"));
        }


    private void checkExistingPublisher(String publisher) {
        reviewRepository.findByPublisher(publisher)
                .ifPresent(cus -> {
                    throw new EntityAlreadyExistsException(String.format("Publisher with the name: %s has given already a rate",publisher));
                });
    }
    public List<Review> getReviews(HttpServletRequest request) {
        for(Review review: reviewRepository.findAll()){
            review.setUrl(String.valueOf(request.getRequestURL()));
            reviewRepository.save(review);
        }
        return reviewRepository.findAll();
    }

    public Review getReviewById(String id, HttpServletRequest request) {
       Review review= reviewRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(String.format("Review not found with id: %s", id)));
       review.setUrl(String.valueOf(request.getRequestURL()));
       return review;
    }

    public void deleteReview(String id) {
        Optional<Review> review= reviewRepository.findById(id);
        if(review.isPresent()){
            reviewRepository.deleteById(id);
        }else{
          throw new EntityNotFoundException(String.format("Review not found with id: %s", id));
        }
    }

    public List<Review> deleteAllReviews() {
        reviewRepository.deleteAll();
        return reviewRepository.findAll();
    }

    // The publisher's name must be correct
    public Review updateAllReviews(Review reviewToUpdate, HttpServletRequest request) {
        if(reviewRepository.count()!=0){
           Optional<Review> review= reviewRepository.findByPublisher(reviewToUpdate.getPublisher());
           if(review.isPresent()){
               reviewToUpdate.setId(review.get().getId());
               for(Review i: reviewRepository.findAll()){
                   if(reviewToUpdate.getStarRating()>5 || reviewToUpdate.getStarRating()<1){
                       throw  new EntityAlreadyExistsException(String.format("please give a rating from 1 to 5"));
                   }
                   if(i.getId()==reviewToUpdate.getId()){
                       i.setUrl(String.valueOf(request.getRequestURL()));
                       i.setStarRating(reviewToUpdate.getStarRating());
                       i.setReviewText(reviewToUpdate.getReviewText());
                       reviewRepository.save(i);
                       return i;
                   }

               }
           }else{
               throw  new EntityNotFoundException(String.format("Publisher with the name: %s is not existing",reviewToUpdate.getPublisher()));
           }
        }else{
            throw  new EntityNotFoundException(String.format("Publisher with the name: %s is not existing",reviewToUpdate.getPublisher()));
        }
        return reviewToUpdate;
    }

    // The publisher's name must be correct
    public Review updateReviewById(String id, Review reviewToUpdate, HttpServletRequest request) {
        if (reviewRepository.count() != 0) {
            Optional<Review> review = reviewRepository.findById(id);
            if (review.isPresent()) {
                reviewToUpdate.setId(review.get().getId());

                Optional<Review> review_2= reviewRepository.findByPublisher(reviewToUpdate.getPublisher());
                if(review_2.isPresent()){
                    for (Review i : reviewRepository.findAll()) {
                        if (reviewToUpdate.getStarRating() > 5 || reviewToUpdate.getStarRating() < 1) {
                            throw new EntityAlreadyExistsException(String.format("please give a rating from 1 to 5"));
                        }
                        if(i.getId()==reviewToUpdate.getId()){
                            i.setUrl(String.valueOf(request.getRequestURL()));
                            i.setStarRating(reviewToUpdate.getStarRating());
                            i.setReviewText(reviewToUpdate.getReviewText());
                            reviewRepository.save(i);
                            return i;
                        }
                    }
                }else {
                    throw  new EntityNotFoundException(String.format("Publisher with the name: %s is not existing",reviewToUpdate.getPublisher()));
                }

            } else {
                throw  new EntityNotFoundException(String.format("Publisher with the id: %s is not existing",id));
            }
        } else {
            throw  new EntityNotFoundException(String.format("Publisher with the id: %s is not existing",id));
        }
        return reviewToUpdate;
    }


}
